
import './App.css';
import React from 'react';
import Pokemon from './components/Pokemon';
function App() {
  return (
    <div>
      <Pokemon />
    </div>
  );
}

export default App;
