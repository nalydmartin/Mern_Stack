
import './App.css';

import React, { useState } from 'react';
import BoxGenerator from './components/BoxGenerator.jsx';

function App() {

  return (
    
    <div className="App">
      <BoxGenerator />
    </div>

    
  );
}

export default App;
