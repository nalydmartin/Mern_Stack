import logo from './logo.svg';
import './App.css';
import { Component } from 'react';

function App() {
  return (
    <>
    <h1>Hello Dojo!</h1>
    <h3>Things I need to do:</h3>
    <ul>
      <li>Learn React</li>
      <li>Climb Mt. Everest</li>
      <li>Go to Austin</li>
      <li>Rob a bank</li>
    </ul>
    </>
  );
}




export default App;
