import React, { useState } from 'react';

const NewUser = props => {

    const { inputs, setInputs } = props;

    const onChange = e => {
        setInputs({
            // Bring in every attribute from form and spread it using ...inputs
            ...inputs,
            [e.target.name]: e.target.value
        });
    };

    return (
        <form >

            <div>
                <label htmlFor="firstName">First Name: </label>
                <input type="text" onChange={ onChange } name="firstName"/>
            </div>
            <div>
                <label htmlFor="lastName">Last Name: </label>
                <input type="text" onChange={ onChange } name="lastName"/>
            </div>
            <div>
                <label htmlFor="email">Email: </label>
                <input type="email" onChange={ onChange } name="email"/>
            </div>
            <div>
                <label htmlFor="password">Password: </label>
                <input type="password" onChange={ onChange } name="password"/>
            </div>
            <div>
                <label htmlFor="confirmPassword">Confirm Password: </label>
                <input type="password" onChange={ onChange } name="confirmPassword"/>
            </div>

            <input type="submit" value="Create User" />
        </form>

    )
}
export default NewUser;