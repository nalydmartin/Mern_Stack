import React from 'react';
import {Router, Link} from '@reach/router';


function Home() {

    

    return (
        <h1>Welcome</h1>
    )
}

export default Home;